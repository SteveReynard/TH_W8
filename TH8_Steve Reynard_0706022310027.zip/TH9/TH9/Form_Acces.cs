﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form_Acces : Form
    {
        Form_Main form;
        private void button1_Click(object sender, EventArgs e)
        {
            form.Cart("Shoe", 120000);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            form.Cart("Black White Shoe", 300000);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            form.Cart("Black Shoe", 150000);
        }
        public Form_Acces(Form_Main form)
        {
            InitializeComponent();
            this.form = form;
        }
    }
}
