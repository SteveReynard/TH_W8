﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form_Top : Form
    {
        Form_Main form;
        private void button1_Click(object sender, EventArgs e)
        {
            form.Cart("Blue T-Shirt", 99000);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            form.Cart("Dark T-Shirt", 120000);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            form.Cart("Gray T-Shirt", 70000);
        }

        public Form_Top(Form_Main form)
        {
            InitializeComponent();
            this.form = form;
        }

        private void Form_Top_Load(object sender, EventArgs e)
        {
        }
    }
}
